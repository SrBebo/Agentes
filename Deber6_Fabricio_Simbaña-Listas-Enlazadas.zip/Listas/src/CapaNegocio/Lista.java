
package CapaNegocio;
 //clase con todos los metodos correspondientes a operaciones con la lista
public class Lista {
    private Nodo first;
    public Lista(){//constructor que establece al primer elemento en lista como vacio 
        first = null;
    }
    
    public void insertFirst(int clave, double num){//metodo para ingresar datos a la lista                                                                      // make new link
        Nodo newLink = new Nodo(clave, num);
        newLink.next = first;                                               
        first = newLink;                                                    
    }
    
    public Nodo find(int clave){//metodo para encontrar el dato en lista segun su clave                                                                     
        Nodo current = first;                                               
        while(current.key != clave)                                         
        {
            if(current.next == null)                                        
                return null;                                                
            else                                                            
                current = current.next;                                     
        }
        return current;                                                     
    }
    
    public Nodo delete(int clave){//metodo para eliminar datos de la lista con la clave                                                                       
        Nodo current = first;                                               
        Nodo previous = first;
        while(current.key != clave)
        {
            if(current.next == null)
                return null;                                                
            else
            {
                previous = current;                                         
                current = current.next;                             
            }
        }                                                                   
        if(current == first)                                                 
            first = first.next;                                              
        else                                                                 
            previous.next = current.next;                                    
        return current;
    }
    
    public void displayList(){//metodo para recorrer la lista y mostrar sus datos
        System.out.print("Lista numeros reales:\n ");
        Nodo current = first;                                              
        while(current != null)                                             
        {
            current.displayLink();                                          
            current = current.next;                                         
        }
        System.out.println("");
    }
    
    boolean isEmpty(){//metodo para saber si la lista esta vacia
        Nodo current = first;
        boolean isEmpty=false;
        if(current == null){
            System.out.println("Empty List");
            isEmpty = true;
        }
        return isEmpty;
    }
    
    public String size(){//metodo para conocer el tamaño de la lista
        int size=0;
        String size2;
        Nodo current = first;
        while(current!=null){
            size +=1;
            current = current.next;
        }
        return size2=""+size;
    }
    
}
