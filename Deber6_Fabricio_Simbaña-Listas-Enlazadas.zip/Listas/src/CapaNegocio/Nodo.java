
package CapaNegocio;


public class Nodo {
    public int key;                                   // key para el numero real ingresado en lista 
    public double num;                                // numero real de la lista
    public Nodo next;                                 // referencia al siguiente dato de lista
    // -------------------------------------------------------------
    public Nodo(int clave, double numero){//metodo constructor
        key = clave;
        num = numero;
    }

    public void displayLink(){ //metodo para mostrar datos de lista
        System.out.print("{" + key + ": " +num + "} \n");
    }
}
